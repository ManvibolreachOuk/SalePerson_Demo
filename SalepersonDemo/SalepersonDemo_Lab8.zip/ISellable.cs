﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SalepersonDemo_Lab8
{
    interface ISellable
    {
        void SalesSpeech();
        void MakeSale(int value);
    }
}
